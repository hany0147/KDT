a = 1
b = 1
print(a < b) # False