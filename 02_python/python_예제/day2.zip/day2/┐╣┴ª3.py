a = 1
result = ""

if a == 1:
    result = True
else:
    result = False

print(result) # True