a = 90

if a == 90:
    a = a + 10
elif a == 100:
    a = a + 10
elif a == 110:
    a = a + 10
else:
    a = a + 10

a = a + 10

print(a) # 110