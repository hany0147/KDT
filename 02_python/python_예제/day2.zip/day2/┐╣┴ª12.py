N = 3
M = 4

for n in range(N):
    for m in range(M):
        print(f"{n}, {m}")

"""
0, 0
0, 1
0, 2
0, 3
1, 0
1, 1
1, 2
1, 3
2, 0
2, 1
2, 2
2, 3
"""