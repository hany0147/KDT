cnt_str = input('문자열을 입력하세요 > ')
cnt = 0
for i in cnt_str:
    if i == 'e':
        cnt += 1

print(cnt)

